class PepitaMaiz extends Modelo {
	constructor(x, y) {
		super(imagenes.icono_recolectable, x, y)
		this.vy = 0;
		this.vx = 0;
	}

}
