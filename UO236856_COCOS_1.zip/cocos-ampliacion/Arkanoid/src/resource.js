var res = {
    HelloWorld_png : "res/HelloWorld.png",
    CloseNormal_png : "res/CloseNormal.png",
    CloseSelected_png : "res/CloseSelected.png",
    bola_png : "res/bola.png",
    barra_1_png : "res/barra_1.png",
    barra_2_png : "res/barra_2.png",
    barra_3_png : "res/barra_3.png",
    barra_3_plist : "res/barra_3.plist",
    fondo_png : "res/fondo.png",
    cocodrilo_1_png : "res/cocodrilo_1.png",
    animacioncocodrilo_png : "res/animacioncocodrilo.png",
    animacioncocodrilo_plist : "res/animacioncocodrilo.plist",
    animacionpanda_png : "res/animacionpanda.png",
    animacionpanda_plist : "res/animacionpanda.plist",
    animaciontigre_png : "res/animaciontigre.png",
    animaciontigre_plist : "res/animaciontigre.plist",
    fondo_2_png : "res/fondo_2.png",
    boton_reanudar_png : "res/boton_reanudar.png",
    boton_siguiente_png : "res/boton_siguiente.png",
    grunt_wav : "res/grunt.wav",
    sonidobucle_wav : "res/sonidobucle.wav",
    animacion_bola_png : "res/animacion_bola.png",
    animacion_bola_plist : "res/animacion_bola.plist"
};

var g_resources = [];
for (var i in res) {
    g_resources.push(res[i]);
}