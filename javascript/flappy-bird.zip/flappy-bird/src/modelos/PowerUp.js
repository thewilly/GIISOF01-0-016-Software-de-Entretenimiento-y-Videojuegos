class PowerUp extends Modelo {
	constructor(x, y) {
		super(imagenes.icono_powerup, x, y)
		this.vy = 0;
		this.vx = 0;
	}

}
