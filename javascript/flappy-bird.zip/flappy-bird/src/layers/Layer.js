class Layer {

    constructor() {

    }

    // En cada iteración fp del juego
    actualizar (){

    }

    dibujar (){

    }

    // Para capas con elementos táctciles
    // Calcula en que botón caen las pulsaciones
    calcularPulsaciones(pulsaciones){

    }

    // Para enviar ordenes de control
    // mover jugador, etc.
    procesarControles(){

    }

}