class Vida extends Modelo {
	constructor(x, y) {
		super(imagenes.icono_corazon, x, y)
		this.vy = 0;
		this.vx = 0;
	}
}
